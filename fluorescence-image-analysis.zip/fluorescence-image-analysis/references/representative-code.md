# 代表图代码参考：先改本次副本，再执行

本文件与[历史代码目录](representative-history/)保存可复现方法，不是已参数化的通用运行入口。先读[当前代表图流程](representative-images.md)中的当前技术检查与裁剪确认规则，按用户已授权阶段改写本次运行副本并验证。不得直接运行归档中的旧路径、固定三组/27对、C2/C3或标尺参数。

## 历史脚本索引与适配要点

| 文件 | 原用途 | 本次使用前必须适配 |
|---|---|---|
| [01_split_merge_fiji.py](representative-history/01_split_merge_fiji.py) | Bio-Formats/ChannelSplitter、原位深TIFF、彩色PNG、调色前Merge | 明确目录/manifest/通道/组数/位深；历史跨组99.5百分位显示策略不是默认；逐视野保存并及时关闭，避免一次加载全批内存 |
| [02_verify_png.py](representative-history/02_verify_png.py) | 单通道与Merge分量检查 | 本次数量/颜色/显示范围/路径，不固定27对 |
| [03_merge_ps_fiji.py](representative-history/03_merge_ps_fiji.py) | PS后RGB分量重组及G3加标尺 | Merge后先技术验收再加标尺，不设置人类效果确认；不原样连跑。替换固定三组、G3、0.2270和旧目录，先验证纯色条件 |
| [04_verify_ps_merge.py](representative-history/04_verify_ps_merge.py) | 重Merge、整数标尺长度及复制一致性 | 本人校准、实际标尺/输出、实际数量，不硬编码440/441像素 |
| [05_prepare_ppt_assets.py](representative-history/05_prepare_ppt_assets.py) | 展示图转为可嵌入PNG | 来源须是本次最终版；不改像素；确认位深适用于此展示转换 |
| [06_build_ppt_layout.mjs](representative-history/06_build_ppt_layout.mjs) | 历史三组大Merge加小通道布局 | 按参考图或默认确定页面/占宽/版式，改实际组数和比例；读取当前Presentations接口，不依赖旧版本；独立图片/文本 |
| [07_finalize_ppt.mjs](representative-history/07_finalize_ppt.mjs) | 历史PPT导出与结构检查 | 发现当前工具/运行时/依赖与导出路径，核对本次页面尺寸/对象数；旧绝对路径不可直接运行 |

这些脚本是实际历史实现的快照，不在scripts/下作为默认入口。不要复制整个旧输出环境作为新实验输入。原始强度保存、RGB展示转换和标尺Flatten是三个不同阶段；发现额外Autoscale或RGB往返重映射时先定位，不自动用调亮抵消。对纯色RGB合并按对应字节分量构造，灰度先明确显示映射。统计均值相同不等于所有像素相同，需按本次数据进行像素/分量核查。

历史脚本03会直接加标尺、历史07含旧工具目录，不代表当前交互与技术检查要求。归档保留原文供理解，执行以前文当前流程为准。PPT用当前工具要求的图片字节嵌入机制并看渲染，不能只看文件生成。

## 历史ImageJ标尺宏代码（完整原文归档）

本节保存查回的原始ImageJ宏，不只是文件链接。以下代码以历史参考归档进本skill，未在整理时重新执行或验证。代码内绝对路径、文件名、批量范围和标尺样式均是历史值；用于新实验前须替换成本次明确的输入/输出及参数，不覆盖原图或已有结果。

历史宏不代表当前交互：当前无PS前/后Merge效果确认，只在裁剪时确认ROI。执行前核对本次来源、配对、显示映射及校准；缺少适用校准则无物理标尺交付，不套未知设备值。样式按当前默认或对应变体，不另问。Flatten后检查标尺区外像素不变。宏内固定路径、批量范围和设备常数必须适配本次；校准优先级见[当前流程](representative-images.md)。

### 宏1 20×单图100 μm白色标尺宏

来源：20×历史代码，已嵌入下文。

历史功能：打开指定TIFF，设置0.2270 μm/像素，右下角绘制100 μm白色标尺，Flatten后另存。

```javascript

 // ==========================================
 // Hypoxia0018.tif 添加20x显微镜标尺
 // ==========================================

 inputDir = "/path/to/local-resource";

 outputDir = inputDir + "标尺/";

 File.makeDirectory(outputDir);

 // 打开原始图片
 open(inputDir + "Hypoxia0018.tif");

 sourceTitle = getTitle();

 // 20x像素校准（由40x换算）
 setVoxelSize(0.2270, 0.2270, 1.0, "um");

 // 添加100μm标尺
 run("Scale Bar...",
     "width=100 height=50 font=150 color=White background=None location=[Lower Right] bold overlay");

 // 固定标尺
 run("Flatten");

 // 保存TIFF
 saveAs("Tiff", outputDir + "Hypoxia0018_20x_ScaleBar.tif");

 close();

 // 关闭原始图片
 if (isOpen(sourceTitle)) {
     selectWindow(sourceTitle);
     close();
 }

 print("==============================");
 print("20x标尺添加完成！");
 print("标尺长度：100 um");
 print("像素校准：0.2270 um/pixel");
 print("输出目录：" + outputDir);
 print("==============================");
```


### 宏2 40×批量100 μm白色标尺宏

来源：40×历史代码，已嵌入下文。

历史功能：遍历输入目录的TIFF，设置0.1135 μm/像素，右下角绘制100 μm白色标尺并另存。原文目录为当时的桌面路径；新任务不能直接运行该路径或遍历未经确认的图片。

```javascript
inputDir = "/path/to/local-resource";

outputDir = "/path/to/local-resource";

File.makeDirectory(outputDir);
files = getFileList(inputDir);

setBatchMode(true);

for (i = 0; i < files.length; i++) {
    name = files[i];
    lowerName = toLowerCase(name);

    if (endsWith(lowerName, ".tif") || endsWith(lowerName, ".tiff")) {
        open(inputDir + name);
        sourceTitle = getTitle();

        setVoxelSize(0.1135, 0.1135, 1.0, "um");

        run("Scale Bar...",
            "width=100 height=50 font=150 color=White background=None location=[Lower Right] bold overlay");

        run("Flatten");
        saveAs("Tiff", outputDir + name);
        close();

        if (isOpen(sourceTitle)) {
            selectWindow(sourceTitle);
            close();
        }

        print("已完成：" + name);
    }
}

setBatchMode(false);
print("大字体标尺版本已完成。");
```


### 宏3 划痕图1000 μm黑色标尺片段（未注明物镜倍率）

来源：划痕历史代码，已嵌入下文。

历史功能：对当前已打开图片设置1.135 μm/像素，在按图宽高比例确定的ROI内绘制1000 μm黑色标尺后Flatten。原文未包含打开、保存和关闭图片的步骤，不是完整批处理入口；不能仅凭此数值将原脚本标为已证实的4×脚本。

```javascript
setVoxelSize(1.135, 1.135, 1.0, "um");

getDimensions(w, h, channels, slices, frames);

x = round(w * 0.62);
y = round(h * 0.84);
rw = round(w * 0.35);
rh = round(h * 0.10);

makeRectangle(x, y, rw, rh);

run("Scale Bar...",
    "width=1000 height=35 font=80 color=Black background=None location=[At Selection] bold overlay");

run("Select None");

// 把比例尺真正合并到图像
run("Flatten");
```

