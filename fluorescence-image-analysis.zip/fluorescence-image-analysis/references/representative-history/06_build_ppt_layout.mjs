import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
export const dir=path.dirname(fileURLToPath(import.meta.url));
export const slideSize={width:36.689/2.54*96,height:51.689/2.54*96};

export async function build(presentation){
  presentation.slides.keep([]);
  const data=JSON.parse(await fs.readFile(path.join(dir,'assets.json'),'utf8'));
  const slide=presentation.slides.add({width:slideSize.width,height:slideSize.height});
  slide.background.fill='#FFFFFF';
  const margin=58,groupGap=18,gap=5,ratio=2748/2200;
  const groupW=(slideSize.width-2*margin-2*groupGap)/3;
  const mainH=(groupW-gap+ratio*gap/2)/(1.5*ratio);
  const mainW=mainH*ratio,smallH=(mainH-gap)/2,smallW=smallH*ratio;
  const top=94;
  function text(name,value,x,y,w,h,size,color,align='left'){
    const s=slide.shapes.add({geometry:'textbox',name,position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
    s.text=value;
    s.text.style={fontFamily:'Arial',fontSize:size,color,alignment:align,verticalAlignment:'middle'};
    s.text.insets=0;
    return s;
  }
  const sources=[];
  for(let i=0;i<data.length;i++){
    const d=data[i],x=margin+i*(groupW+groupGap),sx=x+mainW+gap;
    text(d.group+' title',d.group,x,52,groupW,32,26,'#000000','center');
    for(const [key,frame] of [['merge',{left:x,top,width:mainW,height:mainH}],['green',{left:sx,top,width:smallW,height:smallH}],['blue',{left:sx,top:top+smallH+gap,width:smallW,height:smallH}]]){
      const raw=await fs.readFile(d[key]);
      slide.images.add({dataUrl:'data:image/png;base64,'+raw.toString('base64'),contentType:'image/png',alt:d.group+' '+key+' '+d.base,fit:'contain',position:frame});
      sources.push(d.source[key]);
    }
    text(d.group+' merge label','Merge',x+6,top+4,80,20,14,'#FFFFFF');
    text(d.group+' green label','DAF-FM',sx+4,top+2,smallW-8,18,12,'#FFFFFF');
    text(d.group+' blue label','DAPI',sx+4,top+smallH+gap+2,smallW-8,18,12,'#FFFFFF');
  }
  slide.speakerNotes.text='Source images supplied by the use/path/to/local-resource'+sources.join('\n')+'\nG3 Merge contains the user-approved 100 μm scale bar calibrated at 0.2270 μm/pixel.';
  await fs.mkdir(path.join(dir,'private'),{recursive:true});
  await presentation.render({slide:0,fileName:'DAF-FM_G1_G2_G3_preview.png'});
  await presentation.export({format:'pptx',fileName:'DAF-FM_G1_G2_G3_candidate.pptx'});
  return {slideSize,slideCount:presentation.slides.items.length,figureBottom:top+mainH};
}
