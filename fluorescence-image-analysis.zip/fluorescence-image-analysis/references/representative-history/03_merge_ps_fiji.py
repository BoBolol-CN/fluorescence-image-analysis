# -*- coding: utf-8 -*-
from net.imagej.patcher import LegacyInjector
LegacyInjector.preinit()
from ij import IJ,ImagePlus
from ij.plugin import ChannelSplitter
from ij.process import ColorProcessor
from ij.io import FileSaver
import os,json,jarray

ROOT=u'/path/to/local-resource'
STAGE='/path/to/local-resource'
if not os.path.exists(STAGE):os.makedirs(STAGE)
greens=sorted(n for n in os.listdir(ROOT) if n.endswith('_DAF-FM_Green.tif'))
if len(greens)!=3:raise ValueError('Expected three green/blue pairs')
g3base=None
for name in greens:
    base=name[:-len('_DAF-FM_Green.tif')];blue=base+'_DAPI_Blue.tif'
    g=IJ.openImage(os.path.join(ROOT,name));b=IJ.openImage(os.path.join(ROOT,blue))
    if g is None or b is None or g.getBitDepth()!=24 or b.getBitDepth()!=24 or g.getWidth()!=b.getWidth() or g.getHeight()!=b.getHeight():raise ValueError('Pair image format mismatch')
    gp=ChannelSplitter.split(g);bp=ChannelSplitter.split(b)
    ip=ColorProcessor(g.getWidth(),g.getHeight());ip.setRGB(jarray.zeros(g.getWidth()*g.getHeight(),'b'),gp[1].getProcessor().getPixels(),bp[2].getProcessor().getPixels())
    merged=ImagePlus(base+'_Merge',ip)
    cal=merged.getCalibration();cal.pixelWidth=0.2270;cal.pixelHeight=0.2270;cal.pixelDepth=1.0;cal.setUnit('um')
    for ext in ['tif','png']:
        path=os.path.join(STAGE,base+'_Merge.'+ext)
        if os.path.exists(path):raise ValueError('Refusing overwrite '+path)
        ok=FileSaver(merged).saveAsTiff(path) if ext=='tif' else FileSaver(merged).saveAsPng(path)
        if not ok:raise ValueError('Save failed')
    for im in list(gp)+list(bp)+[g,b,merged]:im.close()
    if base.startswith('G3_'):g3base=base
    print('MERGED '+base)
if g3base is None:raise ValueError('No G3 pair')
macro='''setBatchMode(true);
open("STAGE/BASE_Merge.tif");
sourceTitle=getTitle();
setVoxelSize(0.2270,0.2270,1.0,"um");
run("Scale Bar...","width=100 height=50 font=150 color=White background=None location=[Lower Right] bold overlay");
run("Flatten");
saveAs("Tiff","STAGE/BASE_Merge_20x_ScaleBar.tif");
saveAs("PNG","STAGE/BASE_Merge_20x_ScaleBar.png");
close();
if(isOpen(sourceTitle)){selectWindow(sourceTitle);close();}
setBatchMode(false);
'''.replace('STAGE',STAGE).replace('BASE',g3base)
IJ.runMacro(macro)
if not os.path.exists(os.path.join(STAGE,g3base+'_Merge_20x_ScaleBar.png')):raise ValueError('Scale bar output missing')
with open(os.path.join(STAGE,'completed.json'),'w') as f:json.dump(dict(source=ROOT,pairs=greens,g3=g3base,pixel_size_um=0.2270,scalebar_um=100),f,indent=2)
print('ALL_DONE 3 merges and G3 scale-bar version; TIFF and PNG')
