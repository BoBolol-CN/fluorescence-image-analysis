from pathlib import Path
import hashlib,json,shutil
from PIL import Image
import numpy as np

STAGE=Path(r'/path/to/local-resource')
audit=json.loads((STAGE/'completed.json').read_text())
root=Path(audit['source']);target=root/'Merge'
for name in audit['pairs']:
    base=name.removesuffix('_DAF-FM_Green.tif')
    with Image.open(root/name) as f:g=np.array(f.convert('RGB'))
    with Image.open(root/(base+'_DAPI_Blue.tif')) as f:b=np.array(f.convert('RGB'))
    for ext in ['tif','png']:
        with Image.open(STAGE/(base+'_Merge.'+ext)) as f:m=np.array(f.convert('RGB'))
        assert m.shape==g.shape==b.shape
        assert np.count_nonzero(m[:,:,0])==0
        assert np.array_equal(m[:,:,1],g[:,:,1]) and np.array_equal(m[:,:,2],b[:,:,2])
base=audit['g3']
with Image.open(STAGE/(base+'_Merge.png')) as f:original=np.array(f.convert('RGB'))
with Image.open(STAGE/(base+'_Merge_20x_ScaleBar.png')) as f:scaled=np.array(f.convert('RGB'))
assert original.shape==scaled.shape
white=np.all(scaled==255,axis=2);counts=white.sum(axis=1)
bar_pixels=int(100/0.2270)  # ImageJ Scale Bar uses the integer pixel width.
assert counts.max()==bar_pixels and (counts==bar_pixels).sum()>=50
yy,xx=np.where(np.any(original!=scaled,axis=2))
assert xx.min()>original.shape[1]/2 and yy.min()>original.shape[0]/2
target.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=[p for p in STAGE.iterdir() if p.suffix in ['.tif','.png']]
assert len(files)==8
for p in files:
    q=target/p.name
    if q.exists():
        if digest(p)!=digest(q):raise ValueError('Different existing output '+str(q))
    else:shutil.copy2(p,q)
    assert digest(p)==digest(q)
print(json.dumps(dict(output=str(target),files=len(files),verified='Three exact green/blue merges; G3 100 um scale bar at 0.2270 um/pixel; TIFF and PNG copies match'),ensure_ascii=True))
