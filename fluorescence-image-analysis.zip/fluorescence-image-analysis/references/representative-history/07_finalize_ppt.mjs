import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const workspaceDir=path.dirname(fileURLToPath(import.meta.url));
const skill='/path/to/local-resource';
const published='/path/to/local-resource';
const candidatePath=path.join(workspaceDir,'private','candidate.pptx');
await fs.copyFile(path.join(published,'DAF-FM_G1_G2_G3_candidate.pptx'),candidatePath);
await fs.mkdir(path.join(workspaceDir,'final'),{recursive:true});
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')).href);
const result=await finalizePresentation({
 workspaceDir,candidatePath,finalPath:path.join(workspaceDir,'final','DAF-FM_G1-G3_紧凑拼图.pptx'),
 pythonExecutable:'/path/to/local-resource',
 integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),
 layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),
 layoutArgs:['--expected-slide-size-emu','13208040,18608040','--validate-bullet-geometry','--validate-heading-fit'],
 explicitTotalSlideCount:1,requiredNativeTableOwnerSlides:[],requiredNativeChartOwnerSlides:[],
 fontPolicy:{basis:'design',families:['Arial']},verifyArtifactToolImport:true,
 receiptPath:path.join(workspaceDir,'private','validation.json')
});
console.log(JSON.stringify(result));
