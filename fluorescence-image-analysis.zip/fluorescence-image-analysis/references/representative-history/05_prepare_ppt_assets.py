from pathlib import Path
from PIL import Image
import json

ROOT=Path(r'/path/to/local-resource')
OUT=Path(__file__).resolve().parent
assets=OUT/'assets';assets.mkdir(exist_ok=True)
records=[]
for group in ['G1','G2','G3']:
    green=next(ROOT.glob(group+'*_DAF-FM_Green.tif'))
    base=green.name.removesuffix('_DAF-FM_Green.tif')
    blue=ROOT/(base+'_DAPI_Blue.tif')
    merge=ROOT/'Merge'/(base+('_Merge_20x_ScaleBar.png' if group=='G3' else '_Merge.png'))
    rec={'group':group,'base':base,'source':{}}
    for key,src in [('merge',merge),('green',green),('blue',blue)]:
        with Image.open(src) as im:
            assert im.size==(2748,2200)
            rgb=im.convert('RGB')
            target=assets/(group+'_'+key+'.png');rgb.save(target)
        rec[key]=str(target);rec['source'][key]=str(src)
    records.append(rec)
(OUT/'assets.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print('PREPARED 9 unchanged source images')
