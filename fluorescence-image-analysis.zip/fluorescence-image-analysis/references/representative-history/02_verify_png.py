from pathlib import Path
import json
import numpy as np
from PIL import Image,ImageDraw

OUT=Path(__file__).resolve().parent
audit=json.loads((OUT/'export_audit.json').read_text(encoding='utf-8'))
root=OUT/'DAF-FM_DAPI_拆分及Merge'/'PNG'
contact=Image.new('RGB',(1080,945),'white')
for i,rec in enumerate(audit['pairs']):
    p=rec['pair'];base=p['field_id']+'_'+Path(p['dapi_file']).stem+'_'+Path(p['daf_file']).stem
    folder=root/p['group']
    values=[]
    for suffix in ['DAF-FM_Green','DAPI_Blue','Merge']:
        with Image.open(folder/(base+'_'+suffix+'.png')) as im:
            assert im.mode=='RGB' and im.size==(rec['green']['width'],rec['green']['height'])
            values.append(np.array(im))
    g,b,m=values
    assert np.count_nonzero(g[:,:,(0,2)])==0
    assert np.count_nonzero(b[:,:,(0,1)])==0
    assert np.count_nonzero(m[:,:,0])==0
    assert np.array_equal(m[:,:,1],g[:,:,1]) and np.array_equal(m[:,:,2],b[:,:,2])
    if p['field_id'].endswith('F01'):
        row=int(p['field_id'][1])-1
        for col,(arr,label) in enumerate(zip(values,['DAF-FM Green','DAPI Blue','Merge'])):
            im=Image.fromarray(arr);im.thumbnail((360,288))
            tile=Image.new('RGB',(360,315),'white');tile.paste(im,(0,27));ImageDraw.Draw(tile).text((6,7),p['label']+' '+label,fill='black');contact.paste(tile,(col*360,row*315))
contact.save(OUT/'QC_contact_sheet.png')
print('VERIFIED 27 paired merges: full resolution and exact displayed green/blue components')
