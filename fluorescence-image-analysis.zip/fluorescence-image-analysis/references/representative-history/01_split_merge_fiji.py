# -*- coding: utf-8 -*-
from net.imagej.patcher import LegacyInjector
LegacyInjector.preinit()
from loci.plugins import BF
from loci.plugins.in import ImporterOptions
from ij import IJ,ImagePlus,ImageStack,CompositeImage
from ij.plugin import ChannelSplitter
from ij.io import FileSaver
from ij.process import LUT,ColorProcessor
from java.awt import Color
import os,json,jarray

ROOT=u'/path/to/local-resource'
OUT=u'/path/to/local-resource'
MANIFEST=u'/path/to/local-resource'
FINAL=os.path.join(OUT,u'DAF-FM_DAPI_拆分及Merge')
with open(MANIFEST) as f:pairs=json.load(f)
expected=set(os.path.join(ROOT,p['group'],p[k]) for p in pairs for k in ['daf_file','dapi_file'])
actual=set(os.path.join(d,n) for d,ds,ns in os.walk(ROOT) for n in ns if n.lower().endswith(('.tif','.tiff')))
if actual!=expected or len(pairs)!=27 or len(actual)!=54:raise ValueError('Source inventory changed; review pairing')

def open_channel(path,index):
    opt=ImporterOptions();opt.setId(path);opt.setQuiet(True);opt.setColorMode(ImporterOptions.COLOR_MODE_GRAYSCALE)
    ims=BF.openImagePlus(opt)
    if len(ims)!=1:raise ValueError('Unexpected series')
    original=ims[0]
    if original.getBitDepth()!=16 or original.getNChannels()!=3 or original.getNSlices()!=1 or original.getNFrames()!=1:raise ValueError('Unexpected image format')
    selected=ChannelSplitter.split(original);original.close()
    keep=selected[index]
    for i,im in enumerate(selected):
        if i!=index:im.close()
    return keep

def stats(im):
    ip=im.getProcessor();st=ip.getStatistics();hist=ip.getHistogram();cum=0;p995=0
    for k,n in enumerate(hist):
        cum+=n
        if cum<st.pixelCount*.995:p995=k
    return dict(width=im.getWidth(),height=im.getHeight(),mean=st.mean,minimum=st.min,maximum=st.max,p995=p995,pixels=st.pixelCount)

work=[]
for i,p in enumerate(pairs):
    g=open_channel(os.path.join(ROOT,p['group'],p['daf_file']),1)
    b=open_channel(os.path.join(ROOT,p['group'],p['dapi_file']),2)
    gs=stats(g);bs=stats(b)
    if gs['width']!=bs['width'] or gs['height']!=bs['height']:raise ValueError('Pair dimensions differ')
    work.append((p,g,b,gs,bs))
    print('SPLIT %d/%d %s %s %s'%(i+1,len(pairs),p['field_id'],p['daf_file'],p['dapi_file']))

display={}
for key,idx in [('green',3),('blue',4)]:
    lo=min(w[idx]['minimum'] for w in work);hi=max(lo+1,max(w[idx]['p995'] for w in work))
    display[key]=dict(min=lo,max=hi)

def lut(color,key):
    val=LUT.createLutFromColor(color);val.min=display[key]['min'];val.max=display[key]['max'];return val

def safe_save(im,path,kind):
    if os.path.exists(path):raise ValueError('Existing output; refusing overwrite '+path)
    saver=FileSaver(im)
    ok=saver.saveAsPng(path) if kind=='png' else saver.saveAsTiffStack(path) if im.getStackSize()>1 else saver.saveAsTiff(path)
    if not ok:raise ValueError('Save failed '+path)

audit=[]
for i,(p,g,b,gs,bs) in enumerate(work):
    w=g.getWidth();h=g.getHeight()
    base=p['field_id']+'_'+os.path.splitext(p['dapi_file'])[0]+'_'+os.path.splitext(p['daf_file'])[0]
    dirs={}
    for fmt in ['PNG',u'TIFF_16位']:
        dirs[fmt]=os.path.join(FINAL,fmt,p['group'])
        if not os.path.exists(dirs[fmt]):os.makedirs(dirs[fmt])
    native=[]
    for im,key,col,suffix,st in [(g,'green',Color.GREEN,'DAF-FM_Green',gs),(b,'blue',Color.BLUE,'DAPI_Blue',bs)]:
        im.getProcessor().setColorModel(lut(col,key));im.getProcessor().setMinAndMax(display[key]['min'],display[key]['max'])
        path=os.path.join(dirs[u'TIFF_16位'],base+'_'+suffix+'.tif');safe_save(im,path,'tif');native.append((path,[st]))
    gb=g.getProcessor().convertToByte(True);bb=b.getProcessor().convertToByte(True)
    gb.setColorModel(LUT.createLutFromColor(Color.GREEN));bb.setColorModel(LUT.createLutFromColor(Color.BLUE))
    gp=ImagePlus('DAF-FM Green',gb.convertToRGB());bp=ImagePlus('DAPI Blue',bb.convertToRGB())
    rgb=ColorProcessor(w,h);rgb.setRGB(jarray.zeros(w*h,'b'),gb.getPixels(),bb.getPixels())
    merged_png=ImagePlus('Merge',rgb)
    for im,suffix in [(gp,'DAF-FM_Green'),(bp,'DAPI_Blue'),(merged_png,'Merge')]:
        safe_save(im,os.path.join(dirs['PNG'],base+'_'+suffix+'.png'),'png');im.close()
    # Native merge: a two-channel 16-bit composite, preserving both source planes.
    stack=ImageStack(w,h);stack.addSlice('DAF-FM Green',g.getProcessor().duplicate());stack.addSlice('DAPI Blue',b.getProcessor().duplicate())
    container=ImagePlus(base,stack);container.setDimensions(2,1,1);container.setOpenAsHyperStack(True)
    merged=CompositeImage(container,CompositeImage.COMPOSITE)
    merged.setChannelLut(lut(Color.GREEN,'green'),1);merged.setChannelLut(lut(Color.BLUE,'blue'),2)
    merged.setC(1);merged.setDisplayRange(display['green']['min'],display['green']['max'])
    merged.setC(2);merged.setDisplayRange(display['blue']['min'],display['blue']['max']);merged.setC(1)
    merged_path=os.path.join(dirs[u'TIFF_16位'],base+'_Merge.tif');safe_save(merged,merged_path,'tif');native.append((merged_path,[gs,bs]));merged.close()
    # Reopen each native file and verify shape, bit depth and unchanged mean in every plane.
    for path,planes in native:
        check=IJ.openImage(path)
        if check is None or check.getBitDepth()!=16 or check.getWidth()!=w or check.getHeight()!=h or check.getStackSize()!=len(planes):raise ValueError('TIFF structure mismatch')
        for j,st in enumerate(planes):
            current=check.getStack().getProcessor(j+1).getStatistics()
            if abs(current.mean-st['mean'])>1e-9 or current.pixelCount!=st['pixels']:raise ValueError('Native pixel measurement mismatch')
        if len(planes)==2 and check.getNChannels()!=2:raise ValueError('Merge lost channel metadata')
        check.close()
    g.close();b.close()
    audit.append(dict(pair=p,green=gs,blue=bs))
    print('SAVED_VERIFIED %d/%d %s'%(i+1,len(pairs),p['field_id']))
with open(os.path.join(OUT,'export_audit.json'),'w') as f:json.dump(dict(source_root=ROOT,pairs=audit,display=display,method='Fiji ChannelSplitter; DAF-FM C2 and DAPI C3. Shared per-channel display range from minimum to largest per-image 99.5th percentile; no background subtraction, spatial registration, cropping or rescaling of native pixels. PNG merges use exact displayed green and blue components; TIFF merge retains 16-bit green and blue channels.'),f,indent=2)
print('ALL_DONE 27 pairs; 81 PNG and 81 TIFF')
