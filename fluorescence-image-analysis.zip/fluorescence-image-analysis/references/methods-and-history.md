# 历史方法与参考资料

## 12. 指定历史结果文件夹的完整生成方法

已核对的历史目录：

`/path/to/local-resource`

| 历史输出 | 实际来源/方法 | 泛化时怎样改 |
|---|---|---|
| 00_结果说明.txt | package_results.py 写入指标、公式、通道、参数、QC及局限 | 由本次配置、数量和软件版本生成，不复制旧结论 |
| 01_C2C12_DAF-FM每核荧光结果.csv | process_fiji.py 的 results；package_results.py 重排/中文表头 | 分支选择主指标；新增孔/样本ID，另生成右侧Prism区 |
| 02_ImageJ原始测量明细.csv | 原图目标通道的ImageJ统计、RGB分量均值和背景均值 | 不固定54行、16-bit、固定尺寸或曝光 |
| 03_DAPI逐核明细.csv | CaptureParticles 捕获每个核ROI，换算原图面积和质心，记录边缘标记 | 分支A才产生；核染可为Hoechst/其他通道，面积/坐标按真实缩放换算 |
| 04_原图检查及配对索引.csv | preflight.py 读TIFF/EXIF、manifest映射与组标签 | 改为用户确认的映射和样本层级；去除默认奇偶配对 |
| 核计数检查图 | ImageJ原核通道灰度预览转RGB，画核ROI轮廓和编号 | 保留逐视野可核查预览，不把显示增强用于测量 |
| 核分割掩膜_半分辨率 | 核分割副本0.5倍分辨率的二值掩膜，仅保留计入对象 | 根据本次scale命名，不把所有图都缩到半分辨率 |
| 背景区域检查图 | 核掩膜外扩排除区后取反，显示背景区域的青色轮廓 | 历史背景法仅为选项；新批次需验证，矩形背景实现另存坐标 |
| 每组核计数/背景区域总览JPG | package_results.py 用检查图缩略排版并写视野ID和核数 | 按实际视野数动态分页；不硬编码三组/九张 |
| 可复现脚本 | Fiji核心、启动器、manifest、inventory、日志、verification快照 | 新任务权威代码放2.Code，输出只保留对应快照 |

### 12.1 历史执行顺序

1. preflight.py 清点并按当时确认的奇偶及文件夹规则生成 inventory.json / manifest.json。
2. prepare.py 从此前DAF-FM程序准备C2C12副本；这是历史代码继承步骤，不是新批次的必需步骤。
3. pilot.py 对每组代表图输出通道预览、核分割预览与背景比例，核查映射。
4. run_fiji.ps1 组装本机Fiji jars/plugins类路径，以该Fiji的Java/Jython运行 process_fiji.py；实际统计由ImageJ完成。
5. fiji_common.py 提供 Bio-Formats 导入、ChannelSplitter、核分割、轮廓预览工具。
6. process_fiji.py 完成核数、背景和原始强度测量、CSV前的JSON结果、核ROI/背景检查图、checkpoint与日志。
7. package_results.py 验证数量和公式，生成4类CSV、逐组总览JPG、结果说明和可复现快照。
8. 以前后续还使用 build_prism.py / finalize_prism.py 得到3个孔内均值并操作Prism；新流程已取消这一步，取而代之的是显式孔映射、通用汇总和Excel右侧矩阵。

### 12.2 历史参数，只用于追溯

- 原始强度：完整2748×2200图，R/G/B各16-bit；当时DAPI取蓝、DAF-FM取绿，54张图形成27对视野。
- 核分割：0.5倍工作分辨率，rolling-ball半径50工作像素，Gaussian sigma=2工作像素；Li阈值＋MaximumFinder的Segmented Particles，突出度4000；工作面积≥300，无上限，包含边缘及孔洞。
- 历史背景：核掩膜外扩40工作像素，取剩余区，映射回原图后测量背景均值；可能包含伸长细胞胞质/突起，不能直接保证是无细胞背景。
- 公式：`(绿色RawIntDen − 原图像素数×绿色背景均值)/核数`。不等同于绿色MFI，也不等同于绿/蓝总荧光比。
- 当时设置过大对象、背景比例、近65000上限像素提示。它们是该批规则，不能作为新批次默认阈值。
- 原始measurement JSON与检查图可追溯历史估计；不声称核数为人工真值。

历史脚本含固定路径、三组名称、27/54张检查和特定参数；本草稿保留原文以追溯，但不直接用于通用新任务。原始目录后来整理进`1.Rawdata`，历史脚本路径也不能不检查就运行。


## 15. 一手技术资料

以下资料支持ImageJ命令及接口定义，不代表替本实验选择了分析指标。

- [ImageJ Analyze：Mean、RawIntDen、RGB测量与Analyze Particles](http/path/to/local-resource)。本流程据此区分像素均值、像素和及按核数派生指标，并先分离RGB再测量。
- [ImageJ Particle Analysis](http/path/to/local-resource)。用于核分割/颗粒筛选与分水岭步骤的实现参考；参数仍需对本批图像验证。
- [ImageJ BackgroundSubtracter源代码](http/path/to/local-resource)。用于核分割副本的背景处理接口；其结果不自动用作所有目标通道的背景。

后附完整代码及历史归档索引，使本文离开会话后仍能追溯流程。


