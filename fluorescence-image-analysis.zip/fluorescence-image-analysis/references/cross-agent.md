# 跨客户端运行

## 安装与调用

完整目录包含 SKILL.md、scripts、references 和 assets，必须整体安装，不能只复制入口。
Claude Code 和 Codex 都读取标准 SKILL.md。Claude Code 使用 `/fluorescence-image-analysis`，Codex 使用 `$fluorescence-image-analysis`。工具名称、安装位置和执行授权遵循各自客户端，不假设对方的专属工具存在。

## 工具适配

- 原图定量仍由本地 ImageJ/Fiji 与 Bio-Formats 执行，保留位深与原始测量；不能因为更换客户端就改成展示图定量。
- scripts/build_excel.mjs 使用 @oai/artifact-tool，仅适用于确实装有该模块的环境。其他环境可用 Python openpyxl，从 aggregate_for_prism.py 的 JSON/CSV/TSV 输出重建同样的逐视野明细、孔/样本汇总和右侧 Prism 矩阵；ID 按文本写入，保留数值精度，保存后重读核对。
- PPT 优先使用当前客户端提供的演示文稿工具；没有专有模块时使用 python-pptx 或本地 PowerPoint。图片、标签与组名分离，等比例嵌入，导出预览后复核。历史 @oai 模块只是一个实现示例。
- GraphPad Prism 原生出图需要本地已安装 Prism 及可用自动化接口。随包 .ps1 为 Windows 启动示例；macOS/Linux 应适配本地 Fiji/Prism 的可用接口，不能宣称 Windows 脚本可原样执行。
- Claude 网页对话中导入 ZIP 可以加载规则，但这不自动授予访问本机磁盘、Fiji 或 Prism 的能力；完整本地流程建议使用 Claude Code 或 Codex。

## 公开演示

发布实际结果预览时，先移除实验分组名称和会暴露处理条件的图例、统计图横轴标签、文件路径与说明文字，再叠加水印。仅导出匿名演示副本，保留实验工作文件原样。示例采用通用编号时，不附上真实分组对照表。
