# 配置与运行接口

## 13. 本实现附带的可配置代码

安装包中 `../scripts/`：

- `fiji_quantify.py`：ImageJ真实测量；支持上述三分支的8/16-bit单平面输入、明确通道映射、不扣背景/矩形ROI背景、核计数与轮廓/掩膜。新运行目录，拒绝覆盖。
- `run_fiji.ps1`：参数化Fiji根目录和JSON配置；本机Java位置仍须按安装情况设置，不假定所有机器相同。
- `preflight_inventory.py`：批处理前核对重复层级及原始文件，生成SHA-256和可读元数据清单、未分配文件列表；结束后支持`--verify`检查原图未变。
- `aggregate_for_prism.py`：验证视野→孔→样本关系，处理QC复核与排除，生成JSON、CSV与TSV；不执行Prism。
- `make_qc_overviews.py`：按实际组别、实际视野数分页汇总核/背景检查图，不固定九宫格；文字字体由本机路径提供。
- `build_excel.mjs`：主表左侧明细、右侧动态组别矩阵，另一表记录孔/样本来源；使用当时Spreadsheets skill指定的运行时。
- `run_config.example.json`、`manifest.example.json`：非生产示例，必须补全真实映射和经试算确定参数；`analysis_plan_approved=false`防止空配置误跑。
- `self_check.py`、`self_check_fiji.py`：合成数据/汇总边界检查，不替代新实验的分割、背景和通道试算。

### 13.1 配置接口约定

- `groups`：任意长度列表，每个元素含唯一id、最终label，列表顺序为Excel顺序。
- `replicate_plan`：每个有依据的样本/汇总单元、其孔列表及各孔明确的field_ids；允许不等长，但不允许缺失、重复或错配。默认仅孔级时可以每孔设一个技术汇总单元，明确记录其生物学独立性未知；sample_id只是代码字段，Excel/Prism标题与来源说明应写孔级汇总，不将它描述为独立生物学样本。
- `manifest`：每个field一行，关联group_id/sample_id/well_id及channels；channels内是各角色对应的文件、1-based通道号、背景方式及已知检测上限。
- `mode`：per_nucleus / ratio / single_channel；`target_metric`：mean / raw_intden / corrected_mean / corrected_intden；比值的`ratio_component_metric`也需明确。per_nucleus通常选corrected_intden或raw_intden，不能把该结果标成MFI。
- `nuclei`：明确本次试算参数；scale只支持1或0.5，半分辨率要求宽高可被2整除，否则用scale=1或先扩展坐标换算实现。
- `field_review`：对QC标记逐条写include和reason；可排除或保留，但分母无效等造成的非数值结果不能强行保留。
- `metric_name` / `unit`：用于Excel标签；应与mode、target_metric、背景策略一致。
- `prism_gap_after_group_ids`：可选列表，仅在要求兼容既有模板时插入空列。
- `analysis_plan_approved`：本次类型、来源、映射、指标和试算/执行计划已经明确的状态；可由执行者依据已获授权设定，不代表必须再发一次许可问题。
- `run_purpose`：pilot或batch。`pilot_validated`：代表图分割、背景和测量口径已通过复核；批处理必须为true，不能跳过试算。

示例命令（替换为本机和本实验路径）：

```powershell
# 从实验2.Code本轮脚本目录运行；Fiji需有Bio-Formats和Jython。
# 先清点：
& '<本机Python路径>' .\preflight_inventory.py .\run_config.json
.\run_fiji.ps1 -ConfigPath .\run_config.json -FijiRoot '/path/to/local-resource'
# 结束后复核原图未改：
& '<本机Python路径>' .\preflight_inventory.py --verify .\inventory.json
# 分支适用时生成分页检查总览；字体路径按本机设置：
& '<本机Python路径>' .\make_qc_overviews.py .\run_config.json '<中文字体文件路径>'
# 使用当前桌面环境提供的Python运行聚合脚本。
& '<本机Python路径>' .\aggregate_for_prism.py .\run_config.json
# 先按当前Spreadsheets skill准备node_modules和所需运行标记，再运行：
& '<本机Node路径>' .\build_excel.mjs '<本轮输出>/workbook_payload.json' '<本轮输出>/荧光定量结果.xlsx'
```

上述通用实现是基础版本，不冒充已经覆盖所有显微成像情况。新增格式或方法必须补实现并验证；不允许通过修改标签假装已有相应计算。


## 已观察到的输入与运行时边界

- 原图可能直接位于实验根目录，不为套目录模板擅自移动。此时通用`fiji_quantify.py`会拒绝在`raw_root`下输出，需要在本次运行副本中显式区分实验根目录与已声明的`3.Output`，核对输出不覆盖任何输入；不得简单删除路径保护或对任意输入目录放宽限制。原安装入口仍保留原保护。
- Pillow可能把标签为16-bit的单通道TIFF读成int32容器。复核实际TIFF位深、整数像素范围及与Fiji的像素/测量一致性，不只凭NumPy dtype否定16-bit，也不反过来把int32容器当作32-bit采集。
- 沙箱与提升权限进程的临时目录可能不同。原生程序输出以实际返回的绝对路径定位，不在另一个环境重新拼接`TEMP`去找文件。实际软件位置先查证，不盲用过期安装记录。
