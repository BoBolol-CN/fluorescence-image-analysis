---
name: fluorescence-image-analysis
description: "Analyze fluorescence images with ImageJ/Fiji: raw-image quantification, replicate-aware Excel and native Prism template output; representative images with saved split channels, automatic representative fields, user-prepared PS inputs, verified Merge, calibrated scale bars and editable PPT layouts. Use for 荧光定量、代表图、split/merge、标尺及荧光拼图。"
---

# Fluorescence Image Analysis

本skill分为两部分，可分别使用或按用户要求衔接。第一部分使用真实ImageJ/Fiji定量原图，输出可追溯Excel，并填写匹配的Prism模板及原生出图；第二部分保存拆分通道、自动选代表视野、核验使用者预先完成的PS输入、Merge、标尺和可编辑PPT。

先判断用户要定量、代表图还是两者；不因进入第二部分强制做定量，也不因定量完成自动启动未要求的代表图。完整定量流程默认必须包含Excel和Prism工程/原生图片，不再询问“要不要做Prism”；只有用户明确要求仅Excel或跳过Prism时才省略。展示PNG、PS处理图、Merge和标尺图不回流为定量原图。沿用本轮已明确资料；用户要求模拟陌生实验时，按新实验重新问，不套用旧组名、配对、重复结构、校准或显示参数。

当前交互以[精简询问](references/intake.md)为准：先扫描再建议定量指标；代表图仅问是否裁剪，裁剪时确认ROI。不问组名语义，来源叫什么就写什么；不等待PS前/后Merge效果确认。需要PS由使用者运行前自行完成；原图定量不使用PS图。字体、标尺、页面和占宽按skill/参考图默认，不逐项前置问。用户给示意布局图片就照图做，无图给建议。

代码/参数放指定实验2.Code，结果和可控制的中间图、渲染、缓存、临时目录跟随实验盘，不在C盘建立运行中间目录。原图只读，优先相对路径；迁移先复制并逐文件哈希核对，更新路径后才清理旧工作副本。

## 第一部分：荧光定量分析、Excel与Prism出图


### 先扫描，合并询问实际指标

读[intake](references/intake.md)，自动核查目录、通道和配对。组名直接沿用组文件夹/图片名称，自然排序；数字名不翻译为Control，也不请求确认。

扫描到可信DAPI/Hoechst建议核计数与目标积分荧光/核数；无核染单目标建议MFI；两个目标荧光通道询问是否比值（明确分子/分母）还是分别计算。核染＋目标不机械当比值，同时有核染和双目标则结合探针目的建议。有明确指标不重复问；否则一次给出指标、单位、ROI和背景建议让用户决定。

同次给默认示例：“每孔3个荧光视野，每组3孔，共9个视野；若不同请填写”。无更具体记录且数量适配时按此已授权约定组织，记录默认推定；不将明场/通道文件当独立视野，不把未知独立性写成生物学n。数量或编号无法对应时才补实际结构。具体规则见intake。标题按实际指标自动生成，不单问Title/Y Title。

### 选择分析分支

| 分支 | 指标 |
|---|---|
| per_nucleus | 目标通道原始或背景校正积分荧光 / DAPI或Hoechst核数，AU/核 |
| ratio | 配对视野的红/绿等两个通道标量之比；明确分子、分母、原始或扣背景口径 |
| single_channel | 目标通道MFI或约定总荧光；DCFH-DA绿色只是一个例子 |

核染与指标同时判断；有核染的JC-1仍可能算红/绿，不因存在DAPI就自动改为每核归一化。通道角色可来自任意物理通道或灰度文件。AU/核、像素MFI、RawIntDen和通道比值不可混称。

### 工作目录与脚本

在用户指定实验根目录中使用：

- `1.Rawdata`：只读，保持现有子目录，不擅自移动原图。
- `2.Code/荧光定量_日期_运行编号`：复制本skill相关脚本、填写配置和manifest、记录软件版本/清单/日志。不要在安装的skill目录写运行产物。
- `3.Output/ImageJ_实验名_指标_日期_运行编号`：本次Excel、CSV/TSV、检查图和运行快照。每次使用新目录，不覆盖旧结果。

配置和文件映射见 [references/configuration.md](references/configuration.md)。从 [references/run_config.example.json](references/run_config.example.json) 和 [references/manifest.example.json](references/manifest.example.json) 创建本轮文件；其中参数是待替换示例，不是新实验默认值。

可复用脚本：

- [scripts/preflight_inventory.py](scripts/preflight_inventory.py)：原图校验和/辅助元数据、重复层级和未分配文件清单；支持结束后`--verify`。
- [scripts/fiji_quantify.py](scripts/fiji_quantify.py) 与 [scripts/run_fiji.ps1](scripts/run_fiji.ps1)：Bio-Formats保留位深导入、ImageJ拆分/测量/核计数、原始JSON和检查图。
- [scripts/make_qc_overviews.py](scripts/make_qc_overviews.py)：分组分页检查图总览，字体路径由本机提供。
- [scripts/aggregate_for_prism.py](scripts/aggregate_for_prism.py)：视野→孔→独立样本汇总，验证映射和QC复核，输出CSV/TSV及Excel数据载荷。
- [scripts/build_excel.mjs](scripts/build_excel.mjs)：基于数据载荷生成Excel。读取当前可用的Spreadsheets技能及其工具文档，定位打包依赖和运行时；该模块不替代所需作者标记、导出、渲染和数据检查。

### 执行和复核

1. 清点原图，识别荧光和明场并分别记录用途：明场不纳入荧光强度测量，也不凑入每孔荧光视野数；仅在同视野配对有依据时用于代表图Merge。建立显式manifest及sample→well→field计划。检查通道、位深、同视野配对、尺寸和采集信息。RGB混色图先拆分，不测混色亮度；不能用普通图像读取器将16-bit分量静默降为8-bit。
2. 以少量代表视野先做独立pilot：覆盖各组暗/亮、稀/密和粘连情况。先验证背景选区规则、ROI放大细节及主指标，再扩展全批，避免全批候选生成后多轮返工。检查核轮廓/编号/掩膜、背景ROI及主指标。核分割只处理副本，原始强度不在平滑或二值图上测量。
3. 选定统一的阈值/分离/面积/边缘/背景策略后再批处理。新细胞、新倍率或成像条件需要重新试算，不复制历史C2C12阈值。执行标记表示资料和试算状态已落实，不是要求反复申请用户许可。
4. 配置`run_purpose=pilot`用于试算；检查通过后设置`pilot_validated=true`并使用`run_purpose=batch`。同样本内参数一致，不能按预期组间差异逐组调参。
5. 保留所有原始测量、背景、核对象、QC提示。负校正值保留并复核；零核数、非正比值分母、缺失指标不得填0或无穷大。QC标记不自动等于排除，记录有依据的保留/排除理由。
6. 按本次约定先算每视野指标，再平均同孔视野；若同一样本有多个技术孔，再平均孔均值得一个独立样本值。不能擅自改成汇总分子/分母的加权比值。
7. 复核原图未改变，核查预期/实际数量、公式和右侧矩阵来源，再导出Excel。不要给不完整运行报“全部完成”。

### 交付

主Excel左侧放逐视野明细，右侧留两列间隔后按用户组名/顺序排Prism矩阵，每列一组，每个数据点代表有依据的独立样本；仅按默认孔级组织时明确标为孔均值，独立性未知。组数与每组n可变；不等n下方留空，不补零。只有模板要求时才在组间留空列。

附孔/样本来源表、UTF-8 BOM明细CSV和Prism粘贴TSV；核计数、掩膜和背景检查图按分支提供。每个最终点应可追溯到孔、视野、原图及分析参数。保留测量数值精度，显示格式不改变底层数据。

默认必须交付Excel、Prism可编辑工程和Prism原生导出的图。扫描后确定指标并生成标题、来源名称及映射后写入；不做统计检验或添加星号。

### Prism模板写入与原生出图（完整定量流程必做）

Title按实验名、Y Title按已明确指标与单位自动生成；组名沿用来源，用户可后续修改，不设置标题/组名确认关卡。方法和真实文件归属须有依据，默认重复约定标为推定，不假装采集事实。

读取 [references/prism.md](references/prism.md) 实施。用户模板库为 `/path/to/local-resource`；安装包 [assets/prism_templates/prism_templates.json](assets/prism_templates/prism_templates.json) 收录3、6、8、9组原始PZF。选精确组数模板；其他组数需询问模板/调整方案，不擅自凑组。

只写已核对的样本或明确标注的孔级数据、组名、图Title和Y Title，保留原风格。无新的显著性标注、无额外横线、无其他未要求的样式调整。Y轴默认随实际数据范围调整，覆盖全部散点、柱高及现有误差线并留适当余量，避免旧模板轴限裁掉新数据；只有用户明确要求时保留固定轴限。模板旧显著性/比较线不得混入新图；清理仅在副本上进行。

Prism可编辑工程（PZF/PZFX或当前版本原生格式）、输入映射及脚本放本实验`2.Code`；原生Prism导出的图片放`3.Output`。重新读取保存的数据核对全部组、顺序和数值，再检查实际图Title、Y Title和标注；不使用其他绘图库代替Prism导出。

### 实现边界

当前核心支持8/16-bit的2D平面图，背景仅实现none和同图矩形ROI并集；核分割实现阈值后二值分水岭或MaximumFinder。全视野每核归一化要求包含边缘核；不同计数/荧光ROI需另实现匹配方案。原始像素总和使用像素数，不用标定后的μm²面积代替。

复杂ROI、匹配空白图、不同曝光归一化、3D/时间序列/多series/浮点图、组织与肌管细胞数、阳性率或共定位均先明确相应方法并补实现。不要为了让文件通过而静默投影、转8-bit或使用旧参数。

查核库的定义及历史参数背景时读取 [references/methods-and-history.md](references/methods-and-history.md)。历史仅用于理解；定量入口不使用旧绝对路径，第二部分的历史代码仅在参考资料中归档，不能原样执行。三个分支的合成检查与汇总边界已有记录，见 [references/validation.md](references/validation.md)；其中记录了2026-11-13真实DCFH-DA流程的背景选区、Prism轴限、Excel文本编号及配对视野代表性教训；这些不代替新实验试算，也不证明真实核分割准确率。

## 第二部分：代表图与可编辑PPT

读[代表图入口](references/representative-intake.md)、[技术流程](references/representative-images.md)和[布局](references/representative-layouts.md)。优先照使用者提供的示意布局图片制作；无图时给适用建议，不强制索要附件、不展示A—E全套审批、不单问页面/占宽。

1. Bio-Formats保留原位深，拆分先保存单通道TIFF，再另存展示PNG和映射。
2. AI自动选代表视野并记录ID/依据，有定量时考虑组内代表性；完整视野无需人类最终选图，不按预期差异挑极端值。
3. 核验当前输入（含用户运行前已完成的PS），用ImageJ Merge并检查对应分量，不自动调亮/配准。技术通过直接继续，不等待PS前/后效果确认。
4. 未明确时问“是否裁剪？”不裁直接完成；裁剪则先展示完整图上有ID和坐标的ROI，确认位置/尺寸后正式裁。配对通道同ROI，同实验跨组同约定尺寸；只挪位置保持宽高。
5. 标尺默认100 µm白色右下角加粗，靠近底边，样式/位置/字号/范围自动适配，不前置询问。校准核查和缺失时无标尺交付见技术流程，不捏造物理长度。
6. PPT图片、组名、标签独立可编辑；默认Arial 16 pt、序号28 pt，小图10 pt和纯横线为整区变体。读取当前Presentations技能，核对真实嵌入、比例、对象数、字号、像素来源与最终可读性，交付PPT和预览。

整区、窄幅组合、选框和纯横线见[多实验参考](references/representative-multi-assay-layout.md)。历史代码见[代码参考](references/representative-code.md)，不得原样套固定路径、组名、ROI或校准。

常规询问仅保留：定量实际指标（附默认重复示例）；代表图是否裁剪；要裁时确认ROI。已有答案直接采用，真实技术阻碍只补当前缺项。
