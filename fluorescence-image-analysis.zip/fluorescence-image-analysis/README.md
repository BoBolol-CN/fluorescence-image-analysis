# Fluorescence Image Analysis

Standard Agent Skill for Claude Code and Codex. Install the entire folder with scripts, references and assets.

Claude Code: `/fluorescence-image-analysis`
Codex: `$fluorescence-image-analysis`

See SKILL.md and references/cross-agent.md for workflow and local software requirements.
