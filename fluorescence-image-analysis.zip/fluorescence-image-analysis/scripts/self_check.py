from copy import deepcopy
from aggregate_for_prism import aggregate

def check():
    cfg=dict(groups=[dict(id='A',label='处理甲'),dict(id='B',label='Vehicle')],metric_name='test',unit='AU',replicate_plan=[
        dict(group_id='A',sample_id='S1',wells=[dict(well_id='W1',field_ids=['F1','F2']),dict(well_id='W2',field_ids=['F3'])]),
        dict(group_id='A',sample_id='S2',wells=[dict(well_id='W1',field_ids=['F4'])]),
        dict(group_id='B',sample_id='S1',wells=[dict(well_id='W1',field_ids=['F5'])])])
    rows=[]
    for fid,gid,sid,wid,v in [('F1','A','S1','W1',10),('F2','A','S1','W1',20),('F3','A','S1','W2',30),('F4','A','S2','W1',0),('F5','B','S1','W1',8)]:
        rows.append(dict(field_id=fid,group_id=gid,sample_id=sid,well_id=wid,field_value=v,include=True,qc_status='pass'))
    p=aggregate(cfg,rows)
    assert p['prism_headers']==['处理甲','Vehicle'] and p['prism_rows']==[[22.5,8.0],[0.0,None]]
    bad=deepcopy(rows);bad[0]['qc_status']='review'
    try:aggregate(cfg,bad);raise AssertionError('Unresolved QC accepted')
    except ValueError:pass
    reviewed=deepcopy(cfg);reviewed['field_review']=[dict(field_id='F1',include=False,reason='test exclusion')]
    p=aggregate(reviewed,bad);assert p['prism_rows'][0][0]==25
    for invalid in [rows[:-1],rows+[rows[0]], [dict(r,well_id='wrong') if r['field_id']=='F1' else r for r in rows], [dict(r,field_value=None) if r['field_id']=='F1' else r for r in rows]]:
        try:aggregate(cfg,invalid);raise AssertionError('Invalid mapping/value accepted')
        except ValueError:pass
    print('PASS aggregation: variable labels/n, nested wells, unequal fields, true zero, blank padding, QC exclusion, duplicate/missing/misassigned/undefined rejection')
if __name__=='__main__':check()
