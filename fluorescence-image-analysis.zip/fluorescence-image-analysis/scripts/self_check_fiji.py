# -*- coding: utf-8 -*-
from net.imagej.patcher import LegacyInjector
LegacyInjector.preinit()
from ij import ImagePlus
from ij.process import ShortProcessor
from ij.io import FileSaver
import os,sys,json
sys.path.insert(0,os.path.dirname(__file__))
from fiji_quantify import run
base=os.path.join(os.path.dirname(__file__),sys.argv[1] if len(sys.argv)>1 else 'private_fiji_check')
raw=os.path.join(base,'raw');os.makedirs(raw)
for name,value in [('target',10),('red',20),('green',10),('nuclei',0)]:
    ip=ShortProcessor(64,64);ip.setValue(value);ip.fill()
    if name=='nuclei':
        ip.setValue(5000);ip.fillOval(8,8,10,10);ip.fillOval(40,40,10,10)
    FileSaver(ImagePlus(name,ip)).saveAsTiff(os.path.join(raw,name+'.tif'))
nuc=dict(scale=1,rolling_ball_work_px=0,gaussian_sigma_work_px=0,threshold_method='Li',separation='watershed',edge_policy='include',min_area_original_px2=20,max_area_original_px2=500,min_circularity=0,max_circularity=1)
for mode,roles,expected in [('single_channel',['target'],10),('ratio',['red','green'],2),('per_nucleus',['target','nuclei'],20480)]:
    out=os.path.join(base,mode)
    channels={role:dict(file=role+'.tif',channel_1based=1,background=dict(mode='none')) for role in roles}
    manifest=[dict(field_id='F1',group_id='group-test',sample_id='S1',well_id='W1',channels=channels)]
    manifest_path=os.path.join(base,mode+'_manifest.json')
    with open(manifest_path,'w') as f:json.dump(manifest,f)
    cfg=dict(analysis_plan_approved=True,run_purpose='pilot',raw_root=raw,run_output=out,manifest=manifest_path,mode=mode,target_metric='raw_intden' if mode=='per_nucleus' else 'mean',ratio_component_metric='mean',nuclei=nuc)
    cfgpath=os.path.join(base,mode+'_config.json')
    with open(cfgpath,'w') as f:json.dump(cfg,f)
    run(cfgpath)
    with open(os.path.join(out,'field_measurements.json')) as f:r=json.load(f)[0]
    if abs(r['field_value']-expected)>1e-9:raise ValueError('Unexpected test value '+str(r))
    if mode=='per_nucleus' and r['nuclei_count']!=2:raise ValueError('Wrong synthetic nucleus count')
    print('PASS '+mode+' value='+str(r['field_value']))
# Core cases use none background; rectangle subtraction gets a direct independent test.
from fiji_quantify import measure
from ij import IJ
im=IJ.openImage(os.path.join(raw,'target.tif'))
st=measure(im,dict(background=dict(mode='rectangles',rectangles_xywh=[[0,0,4,4],[2,2,4,4]])),os.path.join(base,'single_channel'),'roi_test','target')
if st['background_pixels']!=28 or st['corrected_mean']!=0:raise ValueError('Background ROI union test failed')
im.close();print('PASS rectangle background union, corrected mean=0, background pixels=28')
