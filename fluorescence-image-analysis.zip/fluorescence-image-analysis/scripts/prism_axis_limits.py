"""Choose linear Y limits from all actual plotted extents, including error bars."""
import math

def choose_linear_axis(extents,target_intervals=4,padding=.10):
    vals=[float(v) for v in extents]
    if not vals or any(not math.isfinite(v) for v in vals):raise ValueError('Finite plotted extents required')
    lo=min(0,min(vals));hi=max(0,max(vals))
    if lo==hi:return dict(bottom=0.,top=1.,interval=.25)
    lo=lo*(1+padding) if lo<0 else 0
    hi=hi*(1+padding) if hi>0 else 0
    wanted=(hi-lo)/target_intervals
    unit=10**math.floor(math.log10(wanted));scaled=wanted/unit
    step=next(v for v in [1,2,2.5,5,10] if v>=scaled)*unit
    return dict(bottom=math.floor(lo/step)*step,top=math.ceil(hi/step)*step,interval=step)

if __name__=='__main__':
    assert choose_linear_axis([3758185,49113843,50700000])==dict(bottom=0.,top=60000000.,interval=20000000.)
    a=choose_linear_axis([-4,3]);assert a['bottom']<-4 and a['top']>3
    print('PASS Y-axis scales: large fluorescence values, negatives, zero baseline')
