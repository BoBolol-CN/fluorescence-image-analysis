// Run using the active Spreadsheets skill's bundled runtime and dependencies.
import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const payload=JSON.parse(await fs.readFile(process.argv[2],'utf8'));
const output=process.argv[3];
try{await fs.access(output);throw new Error('Refusing to overwrite existing workbook');}catch(e){if(e.code!=='ENOENT')throw e;}
const wb=Workbook.create();const sheet=wb.worksheets.add('定量与Prism数据');
sheet.showGridLines=false;
function col(n){let s='';for(n++;n>0;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;}
function scalar(v){return v===undefined?null:Array.isArray(v)||typeof v==='object'&&v!==null?JSON.stringify(v):v;}
const front=['group_label','sample_id','well_id','field_id','field_value','include','qc_status','review_reason'];
const keys=[...front,...[...new Set(payload.details.flatMap(Object.keys))].filter(k=>!front.includes(k))];
const labels={group_label:'组别',sample_id:'独立样本ID',well_id:'孔ID',field_id:'视野ID',field_value:payload.metric_name+' ['+payload.unit+']',include:'纳入汇总',qc_status:'检查状态',review_reason:'复核或排除说明'};
const data=[keys.map(k=>labels[k]??k),...payload.details.map(r=>keys.map(k=>scalar(r[k])))];
// Set text BEFORE values so numeric-looking identifiers retain leading zeros.
for(const key of ['group_label','group_id','sample_id','well_id','field_id']){
  const index=keys.indexOf(key);
  if(index>=0&&data.length>1)sheet.getRange(`${col(index)}2:${col(index)}${data.length}`).setNumberFormat('@');
}
sheet.getRange(`A1:${col(keys.length-1)}${data.length}`).values=data;
const gaps=new Set(payload.config.prism_gap_after_group_ids??[]);
const headers=[],expanded=[];
payload.groups.forEach((g,i)=>{expanded.push(i);headers.push(g.label);if(gaps.has(g.id)&&i<payload.groups.length-1){expanded.push(null);headers.push(null);}});
const start=keys.length+2;
sheet.getRange(`${col(start)}1`).values=[[payload.metric_name+' ['+payload.unit+'] — Prism']];
sheet.getRange(`${col(start)}2:${col(start+headers.length-1)}2`).setNumberFormat('@');
sheet.getRange(`${col(start)}2:${col(start+headers.length-1)}${payload.prism_rows.length+2}`).values=[headers,...payload.prism_rows.map(row=>expanded.map(i=>i===null?null:row[i]))];
sheet.getRange(`A1:${col(keys.length-1)}${data.length}`).format.font={name:'Arial',size:10};
sheet.getRange(`A1:${col(keys.length-1)}1`).format={fill:'#244766',font:{name:'Arial',bold:true,color:'#FFFFFF'}};
sheet.getRange(`A1:${col(keys.length-1)}${data.length}`).format.columnWidth=18;
sheet.getRange('E1:E'+data.length).format.columnWidth=31;
sheet.getRange(`E2:E${data.length}`).setNumberFormat('0.000000');
sheet.getRange(`${col(start)}2:${col(start+headers.length-1)}2`).format={fill:'#244766',font:{name:'Arial',bold:true,color:'#FFFFFF'}};
sheet.getRange(`${col(start)}1:${col(start+headers.length-1)}${payload.prism_rows.length+2}`).format.columnWidth=23;
sheet.getRange(`${col(start)}3:${col(start+headers.length-1)}${payload.prism_rows.length+2}`).setNumberFormat('0.000000');
sheet.freezePanes.freezeRows(1);
const trace=wb.worksheets.add('孔与独立样本来源');trace.showGridLines=false;
const rows=[['组别','独立样本ID','孔ID列表','孔数','样本值'],...payload.samples.map(s=>[s.group_label,s.sample_id,s.well_ids.join(';'),s.well_count,s.sample_value])];
if(rows.length>1)trace.getRange(`A2:C${rows.length}`).setNumberFormat('@');
trace.getRange(`A1:E${rows.length}`).values=rows;trace.getRange(`A1:E${rows.length}`).format.columnWidth=25;
wb.recalculate();
const observed=sheet.getRange(`${col(start)}3:${col(start+headers.length-1)}${payload.prism_rows.length+2}`).values;
for(let r=0;r<payload.prism_rows.length;r++)for(let c=0;c<expanded.length;c++){
  const expected=expanded[c]===null?null:payload.prism_rows[r][expanded[c]],actual=observed[r][c];
  if(expected===null){if(actual!==null&&actual!=='')throw new Error('Missing data converted to a number');}
  else if(typeof actual!=='number'||Math.abs(expected-actual)>1e-12*Math.max(1,Math.abs(expected)))throw new Error('Prism value mismatch');
}
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NUM!',options:{useRegex:true,maxResults:30},maxChars:2000})).ndjson);
const preview=await wb.render({sheetName:sheet.name,range:`${col(start)}1:${col(start+headers.length-1)}${payload.prism_rows.length+2}`,scale:1.5,format:'png'});
await fs.writeFile(path.join(path.dirname(output),'Prism区域_检查用.png'),new Uint8Array(await preview.arrayBuffer()));
await (await SpreadsheetFile.exportXlsx(wb)).save(output);
console.log('EXPORTED',output);
