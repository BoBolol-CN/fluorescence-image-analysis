"""Paginated QC contact sheets. Preview resizing never feeds back into measurements."""
from pathlib import Path
import json,sys,math
from PIL import Image,ImageDraw,ImageFont

cfg=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'));out=Path(cfg['run_output'])
font=ImageFont.truetype(sys.argv[2],16)
rows=json.loads((out/'field_measurements.json').read_text(encoding='utf-8'))
target=out/'QC_overviews';target.mkdir(exist_ok=True)
for group in cfg['groups']:
    records=[r for r in rows if r['group_id']==group['id']]
    for folder in ['nuclei_overlays','background_overlays']:
        items=[]
        for r in records:
            for p in sorted((out/folder).glob(r['field_id']+'*.png')):
                # Guard against prefix collisions such as F1 and F10.
                allowed={r['field_id'],r['field_id']+'_target',r['field_id']+'_nuclei',r['field_id']+'_red',r['field_id']+'_green'}
                if p.stem in allowed:items.append((r,p))
        for page in range(math.ceil(len(items)/12)):
            selection=items[page*12:(page+1)*12];nrows=math.ceil(len(selection)/3)
            canvas=Image.new('RGB',(1440,52+nrows*425),'white');draw=ImageDraw.Draw(canvas)
            draw.text((12,10),group['label']+' | '+folder+' | '+str(page+1),font=font,fill='black')
            for i,(r,p) in enumerate(selection):
                x=(i%3)*480;y=52+(i//3)*425
                draw.text((x+5,y+3),p.stem+' | n='+str(r.get('nuclei_count','n.a.')),font=font,fill='black')
                with Image.open(p) as source:
                    im=source.convert('RGB');im.thumbnail((470,380));canvas.paste(im,(x+5,y+36))
            safe=''.join(c if c.isalnum() or c in '-_' else '_' for c in group['id'])
            canvas.save(target/(safe+'_'+folder+'_'+str(page+1)+'.jpg'),quality=90)
print('QC_OVERVIEWS_DONE')
