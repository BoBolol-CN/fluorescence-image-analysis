"""No ImageJ measurements here: validate hierarchy, aggregate, emit workbook payload."""
from pathlib import Path
from collections import defaultdict
import csv,json,math,statistics,sys

def aggregate(config,rows):
    groups=config['groups'];gids=[g['id'] for g in groups];labels=[g['label'] for g in groups]
    if len(gids)!=len(set(gids)) or len(labels)!=len(set(labels)):raise ValueError('Group IDs/labels must be unique')
    plan=config['replicate_plan'];expected={}
    sample_order={g:[] for g in gids}
    for sample in plan:
        gid=sample['group_id'];sid=sample['sample_id']
        if gid not in sample_order or sid in sample_order[gid]:raise ValueError('Invalid or duplicate sample')
        sample_order[gid].append(sid)
        for well in sample['wells']:
            key=(gid,sid,well['well_id'])
            if key in expected or len(well['field_ids'])!=len(set(well['field_ids'])):raise ValueError('Duplicate well/field mapping')
            if not well['field_ids']:raise ValueError('Empty well plan')
            expected[key]=list(well['field_ids'])
    if any(not sample_order[g] for g in gids):raise ValueError('Each group requires a sample plan')
    assigned=[f for v in expected.values() for f in v]
    if len(assigned)!=len(set(assigned)):raise ValueError('field_id must be globally unique')
    measured={r['field_id']:r for r in rows}
    if len(measured)!=len(rows) or set(measured)!=set(assigned):raise ValueError('Measured fields differ from the explicit replicate plan')
    reviews={r['field_id']:r for r in config.get('field_review',[])}
    if set(reviews)-set(measured):raise ValueError('Review references unknown field')
    included={};detail=[]
    for key,fields in expected.items():
        for fid in fields:
            r=dict(measured[fid])
            if tuple(r[k] for k in ['group_id','sample_id','well_id'])!=key:raise ValueError('Field assigned to wrong sample/well')
            review=reviews.get(fid)
            if r.get('qc_status')!='pass' and review is None:raise ValueError('Unresolved QC review '+fid)
            include=review['include'] if review else r.get('include',True)
            if not isinstance(include,bool):raise ValueError('include must be a boolean')
            if review and not review.get('reason'):raise ValueError('Document every QC override/exclusion')
            value=r.get('field_value')
            if include and (not isinstance(value,(int,float)) or not math.isfinite(value)):raise ValueError('Nonfinite/missing primary value '+fid)
            r.update(group_label=labels[gids.index(key[0])],include=include,review_reason=review.get('reason','') if review else '')
            detail.append(r);included[fid]=include
    wells=[];sample_wells=defaultdict(list)
    for key,fields in expected.items():
        kept=[f for f in fields if included[f]]
        if not kept:raise ValueError('No usable field for well '+str(key))
        value=statistics.fmean(measured[f]['field_value'] for f in kept)
        record=dict(group_id=key[0],sample_id=key[1],well_id=key[2],expected_fields=len(fields),included_fields=len(kept),excluded_fields=len(fields)-len(kept),field_ids=kept,well_value=value)
        wells.append(record);sample_wells[key[:2]].append(record)
    points=[]
    for gid in gids:
        for sid in sample_order[gid]:
            ww=sample_wells[(gid,sid)]
            if not ww:raise ValueError('Missing sample wells')
            points.append(dict(group_id=gid,group_label=labels[gids.index(gid)],sample_id=sid,well_ids=[w['well_id'] for w in ww],well_count=len(ww),sample_value=statistics.fmean(w['well_value'] for w in ww)))
    columns=[[p['sample_value'] for p in points if p['group_id']==gid] for gid in gids]
    # Missing rows in unequal-n groups are blank, never zero.
    matrix=[[col[i] if i<len(col) else None for col in columns] for i in range(max(map(len,columns)))]
    return dict(groups=groups,metric_name=config['metric_name'],unit=config['unit'],details=detail,wells=wells,samples=points,prism_headers=labels,prism_rows=matrix,config=config)

def main():
    config_path=Path(sys.argv[1]);cfg=json.loads(config_path.read_text(encoding='utf-8'))
    rows=json.loads((Path(cfg['run_output'])/'field_measurements.json').read_text(encoding='utf-8'))
    payload=aggregate(cfg,rows);out=Path(cfg['run_output'])
    (out/'workbook_payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    for name,records in [('01_逐视野定量.csv',payload['details']),('02_逐孔汇总.csv',payload['wells']),('03_独立样本汇总.csv',payload['samples'])]:
        fields=list(dict.fromkeys(k for r in records for k in r))
        with (out/name).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
            writer.writerows({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()} for r in records)
    with (out/'04_Prism直接粘贴.tsv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f,delimiter='\t');writer.writerow(payload['prism_headers']);writer.writerows(payload['prism_rows'])
    print('AGGREGATED',len(rows),'fields ->',len(payload['wells']),'wells ->',len(payload['samples']),'independent sample points')

if __name__=='__main__':main()
