"""Read-only provenance inventory. Metadata from Pillow is auxiliary; Fiji validates planes."""
from pathlib import Path
import hashlib,json,sys
from aggregate_for_prism import aggregate

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def main():
    if sys.argv[1]=='--verify':
        audit=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
        for rec in audit['files']:
            p=Path(rec['path']);st=p.stat()
            if st.st_size!=rec['bytes'] or st.st_mtime_ns!=rec['mtime_ns'] or digest(p)!=rec['sha256']:raise ValueError('Source changed '+str(p))
        print('VERIFIED_UNCHANGED',len(audit['files']));return
    cp=Path(sys.argv[1]);cfg=json.loads(cp.read_text(encoding='utf-8'));mp=Path(cfg['manifest'])
    manifest=json.loads(mp.read_text(encoding='utf-8'));root=Path(cfg['raw_root']).resolve()
    dummy=[{**{k:r[k] for k in ['field_id','group_id','sample_id','well_id']},'field_value':0,'include':True,'qc_status':'pass'} for r in manifest]
    aggregate(cfg,dummy)  # Validate hierarchy before expensive image import.
    roles=['target','nuclei'] if cfg['mode']=='per_nucleus' else ['red','green'] if cfg['mode']=='ratio' else ['target']
    byfile={};used=set()
    for r in manifest:
        for role in roles:
            spec=r['channels'][role];p=(root/spec['file']).resolve()
            if not p.is_relative_to(root):raise ValueError('Input path escapes declared raw root')
            key=(str(p),spec['channel_1based'])
            if key in used:raise ValueError('Same source plane reused for multiple fields/roles '+str(key))
            used.add(key);st=p.stat()
            if str(p) not in byfile:
                rec=dict(path=str(p),relative_path=str(p.relative_to(root)),bytes=st.st_size,mtime_ns=st.st_mtime_ns,sha256=digest(p),uses=[],metadata_status='not_read')
                try:
                    from PIL import Image
                    with Image.open(p) as im:
                        tags=getattr(im,'tag_v2',{});exif=im.getexif();extra=exif.get_ifd(34665) if 34665 in exif else {}
                        exposure=tags.get(33434,extra.get(33434))
                        if isinstance(exposure,tuple):exposure=exposure[0]
                        bits=tags.get(258)
                        rec.update(width=im.width,height=im.height,container_mode=im.mode,pages=getattr(im,'n_frames',1),bits_per_sample=list(bits) if isinstance(bits,tuple) else bits,exposure_seconds=float(exposure) if exposure is not None else None,metadata_status='auxiliary_Pillow_metadata_only')
                except Exception as e:rec['metadata_status']='requires_BioFormats_metadata: '+type(e).__name__
                byfile[str(p)]=rec
            byfile[str(p)]['uses'].append(dict(field_id=r['field_id'],role=role,channel_1based=spec['channel_1based']))
    known=set(byfile)
    unassigned=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and str(p.resolve()) not in known]
    snapshot=dict(raw_root=str(root),config_sha256=digest(cp),manifest_sha256=digest(mp),files=list(byfile.values()),unassigned_files=unassigned,unassigned_rule='Review and record whether these are brightfield, excluded acquisition, or missing mappings; never include by guessing.')
    target=cp.parent/'inventory.json'
    if target.exists():raise ValueError('Use new code/run directory; inventory already exists')
    target.write_text(json.dumps(snapshot,ensure_ascii=False,indent=2),encoding='utf-8')
    print('INVENTORY',len(byfile),'used files;',len(unassigned),'unassigned files to review')
if __name__=='__main__':main()
