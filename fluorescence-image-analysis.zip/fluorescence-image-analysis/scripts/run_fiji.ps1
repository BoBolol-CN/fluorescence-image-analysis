param([Parameter(Mandatory=$true)][string]$ConfigPath,[Parameter(Mandatory=$true)][string]$FijiRoot)
$ErrorActionPreference='Stop'
$resolvedConfig=(Resolve-Path -LiteralPath $ConfigPath).Path
$fijiJars=Get-ChildItem -LiteralPath (Join-Path $FijiRoot 'jars') -Recurse -Filter '*.jar' | ForEach-Object FullName
$fijiPlugins=Get-ChildItem -LiteralPath (Join-Path $FijiRoot 'plugins') -Recurse -Filter '*.jar' | ForEach-Object FullName
$fijiCP=($fijiJars+$fijiPlugins) -join ';'
$java=Join-Path $FijiRoot 'java\win64\jdk1.8.0_172\jre\bin\java.exe'
if (-not (Test-Path -LiteralPath $java)) {throw 'Set the installed Fiji Java path for this machine before running; do not install a replacement automatically.'}
$logFile=Join-Path $PSScriptRoot ('fiji_'+[DateTime]::Now.ToString('yyyyMMdd_HHmmss')+'.log')
& $java '-Xmx4g' '-Djava.awt.headless=true' '-Dpython.cachedir.skip=true' -cp $fijiCP org.python.util.jython (Join-Path $PSScriptRoot 'fiji_quantify.py') $resolvedConfig *> $logFile
if($LASTEXITCODE -ne 0) {throw "Fiji failed. Inspect $logFile; do not report a complete result."}
