# -*- coding: utf-8 -*-
"""Fiji/Jython 2.7 core. Parameters and pairings come only from approved JSON."""
from net.imagej.patcher import LegacyInjector
LegacyInjector.preinit()
from loci.plugins import BF
from loci.plugins.in import ImporterOptions
from ij import ImagePlus
from ij.plugin import ChannelSplitter
from ij.plugin.filter import BackgroundSubtracter, GaussianBlur, EDM, ParticleAnalyzer, MaximumFinder
from ij.process import ByteProcessor, ImageProcessor
from ij.measure import ResultsTable, Measurements
from ij.io import FileSaver
from java.awt import Color
import os,sys,json,math

class Capture(ParticleAnalyzer):
    def saveResults(self,st,roi):
        self.rois.append(roi.clone())
        self.stats.append(dict(area=st.area,x=st.xCentroid,y=st.yCentroid))

def load_plane(spec,root):
    path=os.path.abspath(os.path.join(root,spec['file']))
    opt=ImporterOptions();opt.setId(path);opt.setQuiet(True);opt.setColorMode(ImporterOptions.COLOR_MODE_GRAYSCALE)
    images=BF.openImagePlus(opt)
    if len(images)!=1:
        for image in images:image.close()
        raise ValueError('MULTI_SERIES_REQUIRES_REVIEW '+path)
    im=images[0]
    if im.getNSlices()!=1 or im.getNFrames()!=1 or im.getBitDepth() not in [8,16]:
        im.close();raise ValueError('REQUIRES_NEW_3D_TIME_OR_FLOAT_PLAN '+path)
    planes=ChannelSplitter.split(im);im.close()
    index=int(spec['channel_1based'])-1
    if index<0 or index>=len(planes):raise ValueError('CHANNEL_NOT_FOUND '+path)
    keep=planes[index]
    for i,plane in enumerate(planes):
        if i!=index:plane.close()
    keep.getProcessor().resetRoi();keep.getProcessor().resetThreshold()
    return keep

def measure(im,spec,outdir,fid,role):
    ip=im.getProcessor();ip.resetRoi();ip.resetThreshold();st=ip.getStatistics()
    hist=ip.getHistogram();total=sum(int(k)*int(n) for k,n in enumerate(hist))
    if sum(hist)!=st.pixelCount or abs(total-st.mean*st.pixelCount)>max(.001,abs(total)*1e-12):raise ValueError('PIXEL_RECONCILIATION_FAILED')
    out=dict(mean=st.mean,raw_intden=total,pixel_count=st.pixelCount,minimum=st.min,maximum=st.max,bit_depth=im.getBitDepth())
    ceiling=spec.get('detector_ceiling')
    if ceiling is not None:
        if int(ceiling)!=ceiling or not 0<=ceiling<len(hist):raise ValueError('INVALID_DETECTOR_CEILING')
        out['ceiling_pixels']=sum(hist[int(ceiling):])
    else:out['ceiling_pixels']=None
    mode=spec['background']['mode']
    if mode=='none':
        out.update(background_mean=None,background_pixels=0,corrected_mean=None,corrected_intden=None)
    elif mode=='rectangles':
        mask=ByteProcessor(im.getWidth(),im.getHeight());mask.setValue(255)
        boxes=spec['background']['rectangles_xywh']
        if not boxes:raise ValueError('NO_BACKGROUND_ROI')
        for x,y,w,h in boxes:
            if any(int(v)!=v for v in [x,y,w,h]) or min(x,y)<0 or min(w,h)<=0 or x+w>im.getWidth() or y+h>im.getHeight():raise ValueError('INVALID_BACKGROUND_RECTANGLE')
            mask.setRoi(int(x),int(y),int(w),int(h));mask.fill()
        mask.resetRoi();ip.setRoi(0,0,im.getWidth(),im.getHeight());ip.setMask(mask)
        bg=ip.getStatistics();ip.resetRoi()
        if bg.pixelCount<=0:raise ValueError('EMPTY_BACKGROUND_ROI')
        out.update(background_mean=bg.mean,background_pixels=bg.pixelCount,corrected_mean=st.mean-bg.mean,corrected_intden=total-st.pixelCount*bg.mean)
        view=ip.duplicate();view.setMinAndMax(st.min,max(st.min+1,st.max));view=view.convertToByte(True).convertToRGB();view.setColor(Color(0,220,255))
        for x,y,w,h in boxes:view.drawRect(int(x),int(y),int(w),int(h))
        FileSaver(ImagePlus('background ROIs',view)).saveAsPng(os.path.join(outdir,'background_overlays',fid+'_'+role+'.png'))
    else:raise ValueError('BACKGROUND_METHOD_REQUIRES_IMPLEMENTATION '+mode)
    return out

def count_nuclei(im,cfg,outdir,fid):
    scale=float(cfg['scale'])
    if scale not in [1.0,.5]:raise ValueError('SUPPORTED_NUCLEUS_SCALE_IS_1_OR_HALF')
    w,h=im.getWidth(),im.getHeight()
    if scale==.5 and (w%2 or h%2):raise ValueError('ODD_DIMENSIONS_USE_SCALE_1')
    ip=im.getProcessor().duplicate() if scale==1 else im.getProcessor().resize(int(w*scale),int(h*scale),True)
    radius=float(cfg['rolling_ball_work_px'])
    if radius>0:BackgroundSubtracter().rollingBallBackground(ip,radius,False,False,False,True,True)
    sigma=float(cfg['gaussian_sigma_work_px'])
    if sigma>0:GaussianBlur().blurGaussian(ip,sigma)
    ip.setAutoThreshold(cfg['threshold_method']+' dark');threshold=ip.getMinThreshold()
    if cfg['separation']=='watershed':
        mask=ip.createMask();EDM().toWatershed(mask)
    elif cfg['separation']=='maxima':
        mask=MaximumFinder().findMaxima(ip,float(cfg['maxima_prominence']),threshold,MaximumFinder.SEGMENTED,False,False)
    else:raise ValueError('UNKNOWN_NUCLEUS_SEPARATION')
    options=ParticleAnalyzer.INCLUDE_HOLES
    if cfg['edge_policy']=='exclude':options|=ParticleAnalyzer.EXCLUDE_EDGE_PARTICLES
    elif cfg['edge_policy']!='include':raise ValueError('UNKNOWN_EDGE_POLICY')
    pa=Capture(options,Measurements.AREA|Measurements.CENTROID,ResultsTable(),float(cfg['min_area_original_px2'])*scale*scale,float(cfg['max_area_original_px2'])*scale*scale,float(cfg['min_circularity']),float(cfg['max_circularity']))
    pa.rois=[];pa.stats=[]
    mask.setThreshold(255,255,ImageProcessor.NO_LUT_UPDATE)
    if not pa.analyze(ImagePlus('nuclear mask',mask)):raise ValueError('NUCLEUS_ANALYSIS_FAILED')
    clean=ByteProcessor(ip.getWidth(),ip.getHeight());clean.setValue(255)
    gray=im.getProcessor().resize(ip.getWidth(),ip.getHeight(),True)
    gray.setMinAndMax(im.getProcessor().getStatistics().min,im.getProcessor().getStatistics().max)
    preview=gray.convertToByte(True).convertToRGB();preview.setColor(Color(0,255,80))
    rows=[]
    for i,(roi,st) in enumerate(zip(pa.rois,pa.stats)):
        clean.fill(roi);preview.draw(roi);bounds=roi.getBounds();preview.drawString(str(i+1),bounds.x,bounds.y)
        rows.append(dict(field_id=fid,nucleus_id=i+1,area_original_px2=st['area']/(scale*scale),x_original_px=st['x']/scale,y_original_px=st['y']/scale,touches_edge=bounds.x==0 or bounds.y==0 or bounds.x+bounds.width>=ip.getWidth() or bounds.y+bounds.height>=ip.getHeight()))
    FileSaver(ImagePlus('mask',clean)).saveAsPng(os.path.join(outdir,'nuclei_masks',fid+'.png'))
    FileSaver(ImagePlus('overlay',preview)).saveAsPng(os.path.join(outdir,'nuclei_overlays',fid+'.png'))
    return len(rows),rows,threshold

def run(config_path):
    with open(config_path) as f:cfg=json.load(f)
    if cfg.get('analysis_plan_approved') is not True:raise ValueError('CONFIRM_ANALYSIS_PLAN_BEFORE_BATCH')
    if cfg.get('run_purpose','batch') not in ['pilot','batch']:raise ValueError('INVALID_RUN_PURPOSE')
    if cfg.get('run_purpose','batch')=='batch' and cfg.get('pilot_validated') is not True:raise ValueError('VALIDATE_REPRESENTATIVE_PILOT_BEFORE_BATCH')
    if cfg['mode']=='per_nucleus' and cfg['nuclei']['edge_policy']!='include':raise ValueError('FULL_FRAME_NORMALIZATION_REQUIRES_MATCHED_EDGE_POLICY')
    if cfg['mode']=='per_nucleus' and cfg['target_metric'] not in ['raw_intden','corrected_intden']:raise ValueError('PER_NUCLEUS_MODE_REQUIRES_INTEGRATED_SIGNAL')
    if cfg['mode']=='ratio' and cfg['ratio_component_metric'] not in ['mean','corrected_mean','raw_intden','corrected_intden']:raise ValueError('INVALID_RATIO_METRIC')
    if cfg['mode']=='single_channel' and cfg['target_metric'] not in ['mean','corrected_mean','raw_intden','corrected_intden']:raise ValueError('INVALID_TARGET_METRIC')
    root=os.path.abspath(cfg['raw_root']);out=os.path.abspath(cfg['run_output'])
    if out==root or out.startswith(root+os.sep):raise ValueError('OUTPUT_MUST_NOT_BE_INSIDE_RAWDATA')
    if os.path.exists(out):raise ValueError('USE_A_NEW_RUN_DIRECTORY')
    for sub in ['', 'nuclei_masks','nuclei_overlays','background_overlays']:os.makedirs(os.path.join(out,sub))
    with open(cfg['manifest']) as f:manifest=json.load(f)
    ids=[r['field_id'] for r in manifest]
    if len(ids)!=len(set(ids)) or any(not fid or any(c in fid for c in '/\\:') for fid in ids):raise ValueError('INVALID_OR_DUPLICATE_FIELD_ID')
    results=[];nuclei=[]
    for field in manifest:
        row=dict(field_id=field['field_id'],group_id=field['group_id'],sample_id=field['sample_id'],well_id=field['well_id'],include=True,qc_status='pass',review_reasons=[])
        mode=cfg['mode'];roles=['target','nuclei'] if mode=='per_nucleus' else ['red','green'] if mode=='ratio' else ['target'] if mode=='single_channel' else None
        if roles is None:raise ValueError('UNKNOWN_ANALYSIS_MODE')
        opened={};measured={};dimensions=None
        try:
            for role in roles:
                spec=field['channels'][role];im=load_plane(spec,root);opened[role]=im
                dims=(im.getWidth(),im.getHeight())
                if dimensions is not None and dimensions!=dims:raise ValueError('PAIRED_DIMENSIONS_DIFFER')
                dimensions=dims;st=measure(im,spec,out,row['field_id'],role);measured[role]=st
                row[role+'_source']=spec['file'];row[role+'_channel_1based']=spec['channel_1based']
                for key,value in st.items():row[role+'_'+key]=value
                if st['ceiling_pixels'] is not None and st['ceiling_pixels']>0:row['review_reasons'].append(role+'_AT_DETECTOR_CEILING')
                if st['corrected_mean'] is not None and st['corrected_mean']<0:row['review_reasons'].append(role+'_NEGATIVE_CORRECTED_SIGNAL')
            if mode=='per_nucleus':
                n,objects,threshold=count_nuclei(opened['nuclei'],cfg['nuclei'],out,row['field_id'])
                nuclei.extend(objects);row.update(nuclei_count=n,nuclear_threshold=threshold)
                numerator=measured['target'][cfg['target_metric']]
                value=numerator/n if numerator is not None and n>0 else None
                if n==0:row['review_reasons'].append('ZERO_NUCLEI')
            elif mode=='ratio':
                r=measured['red'][cfg['ratio_component_metric']];g=measured['green'][cfg['ratio_component_metric']]
                value=r/g if r is not None and g is not None and g>0 else None
                if g is None or g<=0:row['review_reasons'].append('NONPOSITIVE_OR_MISSING_DENOMINATOR')
            else:value=measured['target'][cfg['target_metric']]
            row['field_value']=value
            if value is None:row['review_reasons'].append('MISSING_PRIMARY_METRIC')
            if row['review_reasons']:row['qc_status']='review'
            results.append(row)
            with open(os.path.join(out,'field_measurements.json'),'w') as f:json.dump(results,f,ensure_ascii=True,indent=2)
        finally:
            for image in opened.values():image.close()
        print('DONE '+row['field_id'])
    with open(os.path.join(out,'nuclei_objects.json'),'w') as f:json.dump(nuclei,f,ensure_ascii=True,indent=2)
    with open(os.path.join(out,'run_config_snapshot.json'),'w') as f:json.dump(cfg,f,ensure_ascii=True,indent=2)
    print('ALL_DONE '+str(len(results)))

if __name__=='__main__':run(sys.argv[1])
